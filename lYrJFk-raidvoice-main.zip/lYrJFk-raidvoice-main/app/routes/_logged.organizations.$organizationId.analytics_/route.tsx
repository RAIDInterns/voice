import { useUserContext } from '@/core/context'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'
import { useParams } from '@remix-run/react'
import { Card, Col, DatePicker, Row, Statistic, Table, Typography } from 'antd'
import dayjs from 'dayjs'
import { useState } from 'react'
const { Title, Text } = Typography
const { RangePicker } = DatePicker

export default function AnalyticsPage() {
  const { organizationId } = useParams()
  const { user, checkOrganizationRole } = useUserContext()
  const isAdmin = user?.globalRole === 'ADMIN'
  const [dateRange, setDateRange] = useState<[dayjs.Dayjs, dayjs.Dayjs]>([
    dayjs().subtract(30, 'days'),
    dayjs(),
  ])

  // Fetch conversations with sentiment analysis
  const { data: conversations } = Api.conversation.findMany.useQuery({
    where: { organizationId },
    orderBy: { createdAt: 'desc' },
  })

  // Fetch credit transactions
  const { data: transactions } = Api.creditTransaction.findMany.useQuery({
    where: { organizationId },
  })

  // Fetch bots
  const { data: bots } = Api.bot.findMany.useQuery({
    where: { organizationId },
  })

  // Calculate metrics
  const totalConversations = conversations?.length || 0
  const positiveSentiments =
    conversations?.filter(c => c.sentiment === 'positive').length || 0
  const negativeSentiments =
    conversations?.filter(c => c.sentiment === 'negative').length || 0
  const sentimentRatio = totalConversations
    ? ((positiveSentiments / totalConversations) * 100).toFixed(1)
    : '0'

  // Prepare conversation table data
  const conversationColumns = [
    {
      title: 'Date',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (date: string) => dayjs(date).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'Sentiment',
      dataIndex: 'sentiment',
      key: 'sentiment',
      render: (sentiment: string) => (
        <Text type={sentiment === 'positive' ? 'success' : 'danger'}>
          <i
            className={`las ${
              sentiment === 'positive' ? 'la-smile' : 'la-frown'
            } mr-2`}
          ></i>
          {sentiment}
        </Text>
      ),
    },
  ]

  return (
    <PageLayout layout="full-width">
      <div className="max-w-7xl mx-auto px-4">
        <div className="mb-8">
          <Title level={2}>
            <i className="las la-chart-line mr-2"></i>
            Analytics Dashboard
          </Title>
          <Text type="secondary">
            Comprehensive insights into conversations, bot performance, and user
            engagement
          </Text>
        </div>

        <Row gutter={[16, 16]} className="mb-8">
          <Col xs={24} sm={12} lg={6}>
            <Card>
              <Statistic
                title="Total Conversations"
                value={totalConversations}
                prefix={<i className="las la-comments"></i>}
              />
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={6}>
            <Card>
              <Statistic
                title="Positive Sentiment"
                value={sentimentRatio}
                suffix="%"
                prefix={<i className="las la-smile"></i>}
              />
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={6}>
            <Card>
              <Statistic
                title="Active Bots"
                value={bots?.filter(b => b.status === 'active').length || 0}
                prefix={<i className="las la-robot"></i>}
              />
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={6}>
            <Card>
              <Statistic
                title="Credits Used"
                value={transactions?.reduce((acc, t) => acc + t.amount, 0) || 0}
                prefix={<i className="las la-coins"></i>}
              />
            </Card>
          </Col>
        </Row>

        {isAdmin && (
          <Card className="mb-8">
            <Title level={4}>
              <i className="las la-user-shield mr-2"></i>
              Admin Analytics
            </Title>
            <Row gutter={[16, 16]}>
              <Col xs={24} sm={8}>
                <Statistic
                  title="Total Users"
                  value={conversations?.filter(c => c.userId).length || 0}
                  prefix={<i className="las la-users"></i>}
                />
              </Col>
              <Col xs={24} sm={8}>
                <Statistic
                  title="System Uptime"
                  value="99.9"
                  suffix="%"
                  prefix={<i className="las la-server"></i>}
                />
              </Col>
              <Col xs={24} sm={8}>
                <Statistic
                  title="API Requests"
                  value={transactions?.length || 0}
                  prefix={<i className="las la-network-wired"></i>}
                />
              </Col>
            </Row>
          </Card>
        )}

        <Card className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <Title level={4}>
              <i className="las la-history mr-2"></i>
              Conversation History
            </Title>
            <RangePicker
              value={dateRange}
              onChange={dates => dates && setDateRange(dates)}
            />
          </div>
          <Table
            dataSource={conversations?.filter(
              c =>
                dayjs(c.createdAt).isAfter(dateRange[0]) &&
                dayjs(c.createdAt).isBefore(dateRange[1]),
            )}
            columns={conversationColumns}
            rowKey="id"
            pagination={{ pageSize: 10 }}
          />
        </Card>
      </div>
    </PageLayout>
  )
}
