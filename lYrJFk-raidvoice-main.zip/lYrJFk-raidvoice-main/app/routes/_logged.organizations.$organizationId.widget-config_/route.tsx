import { useUserContext } from '@/core/context'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'
import { useParams } from '@remix-run/react'
import {
  Button,
  Card,
  Col,
  Form,
  Input,
  message,
  Row,
  Select,
  Space,
  Typography,
} from 'antd'
import { useState } from 'react'
const { Title, Text } = Typography

export default function WidgetConfigurationPage() {
  const { organizationId } = useParams()
  const { user } = useUserContext()
  const [selectedWidget, setSelectedWidget] = useState<string>()
  const [previewMode, setPreviewMode] = useState(false)

  // Fetch widgets
  const { data: widgets, refetch } = Api.widget.findMany.useQuery({
    where: { organizationId },
    include: { user: true },
  })

  // Mutations
  const { mutateAsync: createWidget } = Api.widget.create.useMutation()
  const { mutateAsync: updateWidget } = Api.widget.update.useMutation()
  const { mutateAsync: deleteWidget } = Api.widget.delete.useMutation()

  const [form] = Form.useForm()

  const handleSave = async (values: any) => {
    try {
      const widgetData = {
        name: values.name,
        config: JSON.stringify({
          theme: values.theme,
          position: values.position,
          primaryColor: values.primaryColor,
          textColor: values.textColor,
          fontSize: values.fontSize,
        }),
        embedCode: generateEmbedCode(values),
        status: 'ACTIVE',
        organizationId: organizationId!,
        userId: user!.id,
      }

      if (selectedWidget) {
        await updateWidget({
          where: { id: selectedWidget },
          data: widgetData,
        })
      } else {
        await createWidget({ data: widgetData })
      }

      message.success('Widget configuration saved successfully')
      refetch()
      form.resetFields()
      setSelectedWidget(undefined)
    } catch (error) {
      message.error('Failed to save widget configuration')
    }
  }

  const generateEmbedCode = (config: any) => {
    return `<script>
      window.widgetConfig = {
        theme: "${config.theme}",
        position: "${config.position}",
        primaryColor: "${config.primaryColor}",
        textColor: "${config.textColor}",
        fontSize: "${config.fontSize}"
      };
    </script>
    <script src="https://your-widget-url.com/embed.js"></script>`
  }

  const handleDelete = async (widgetId: string) => {
    try {
      await deleteWidget({ where: { id: widgetId } })
      message.success('Widget deleted successfully')
      refetch()
    } catch (error) {
      message.error('Failed to delete widget')
    }
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <Title level={2}>
          <i className="las la-cog" /> Widget Configuration
        </Title>
        <Text>
          Customize and manage your chat and voice widgets appearance and
          deployment settings.
        </Text>

        <Row gutter={[24, 24]} style={{ marginTop: 24 }}>
          <Col xs={24} lg={16}>
            <Card
              title={
                <>
                  <i className="las la-edit" /> Widget Editor
                </>
              }
            >
              <Form form={form} layout="vertical" onFinish={handleSave}>
                <Form.Item
                  name="name"
                  label="Widget Name"
                  rules={[{ required: true }]}
                >
                  <Input placeholder="Enter widget name" />
                </Form.Item>

                <Form.Item
                  name="theme"
                  label="Theme"
                  rules={[{ required: true }]}
                >
                  <Select>
                    <Select.Option value="light">Light</Select.Option>
                    <Select.Option value="dark">Dark</Select.Option>
                  </Select>
                </Form.Item>

                <Form.Item
                  name="position"
                  label="Widget Position"
                  rules={[{ required: true }]}
                >
                  <Select>
                    <Select.Option value="bottom-right">
                      Bottom Right
                    </Select.Option>
                    <Select.Option value="bottom-left">
                      Bottom Left
                    </Select.Option>
                  </Select>
                </Form.Item>

                <Form.Item
                  name="primaryColor"
                  label="Primary Color"
                  rules={[{ required: true }]}
                >
                  <Input type="color" />
                </Form.Item>

                <Form.Item
                  name="textColor"
                  label="Text Color"
                  rules={[{ required: true }]}
                >
                  <Input type="color" />
                </Form.Item>

                <Form.Item
                  name="fontSize"
                  label="Font Size"
                  rules={[{ required: true }]}
                >
                  <Select>
                    <Select.Option value="small">Small</Select.Option>
                    <Select.Option value="medium">Medium</Select.Option>
                    <Select.Option value="large">Large</Select.Option>
                  </Select>
                </Form.Item>

                <Space>
                  <Button type="primary" htmlType="submit">
                    <i className="las la-save" /> Save Widget
                  </Button>
                  <Button onClick={() => setPreviewMode(!previewMode)}>
                    <i className="las la-eye" /> Toggle Preview
                  </Button>
                </Space>
              </Form>
            </Card>
          </Col>

          <Col xs={24} lg={8}>
            <Card
              title={
                <>
                  <i className="las la-list" /> Existing Widgets
                </>
              }
            >
              {widgets?.map(widget => (
                <Card key={widget.id} size="small" style={{ marginBottom: 16 }}>
                  <Space direction="vertical" style={{ width: '100%' }}>
                    <Text strong>{widget.name}</Text>
                    <Space>
                      <Button
                        size="small"
                        onClick={() => {
                          setSelectedWidget(widget.id)
                          form.setFieldsValue({
                            name: widget.name,
                            ...JSON.parse(widget.config),
                          })
                        }}
                      >
                        <i className="las la-edit" /> Edit
                      </Button>
                      <Button
                        size="small"
                        danger
                        onClick={() => handleDelete(widget.id)}
                      >
                        <i className="las la-trash" /> Delete
                      </Button>
                    </Space>
                  </Space>
                </Card>
              ))}
            </Card>
          </Col>
        </Row>

        {previewMode && (
          <Card
            title={
              <>
                <i className="las la-mobile" /> Widget Preview
              </>
            }
            style={{ marginTop: 24 }}
          >
            <div
              style={{
                height: 400,
                background: '#f0f2f5',
                position: 'relative',
              }}
            >
              {/* Preview implementation would go here */}
              <div
                style={{
                  position: 'absolute',
                  bottom: 20,
                  right: 20,
                  width: 60,
                  height: 60,
                  borderRadius: '50%',
                  backgroundColor:
                    form.getFieldValue('primaryColor') || '#1890ff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                }}
              >
                <i
                  className="las la-comments"
                  style={{ color: '#fff', fontSize: 24 }}
                />
              </div>
            </div>
          </Card>
        )}
      </div>
    </PageLayout>
  )
}
