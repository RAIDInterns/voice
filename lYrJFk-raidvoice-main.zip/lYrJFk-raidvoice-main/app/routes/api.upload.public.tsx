import { UploadServer } from '../plugins/upload/server'

export const action = UploadServer.actionPublic
