import {
  Typography,
  Card,
  Input,
  Button,
  Space,
  Select,
  Row,
  Col,
  message,
} from 'antd'
import { useState } from 'react'
const { Title, Text } = Typography
const { TextArea } = Input
import { useUserContext } from '@/core/context'
import dayjs from 'dayjs'
import { useLocation, useNavigate, useParams } from '@remix-run/react'
import { useUploadPublic } from '@/plugins/upload/client'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function BotBuilderPage() {
  const { organizationId } = useParams()
  const { user } = useUserContext()
  const [selectedTemplate, setSelectedTemplate] = useState<string>('')
  const [workflow, setWorkflow] = useState<string>('')
  const [botName, setBotName] = useState<string>('')
  const [testPrompt, setTestPrompt] = useState<string>('')
  const [testResponse, setTestResponse] = useState<string>('')

  // Fetch existing bots
  const { data: bots, refetch } = Api.bot.findMany.useQuery({
    where: { organizationId },
    orderBy: { createdAt: 'desc' },
  })

  // Create bot mutation
  const { mutateAsync: createBot } = Api.bot.create.useMutation()

  // AI generation mutation
  const { mutateAsync: generateResponse } = Api.ai.generateText.useMutation()

  const templates = [
    { value: 'customer_service', label: 'Customer Service Bot' },
    { value: 'sales', label: 'Sales Assistant' },
    { value: 'technical_support', label: 'Technical Support' },
  ]

  const handleCreateBot = async () => {
    try {
      await createBot({
        data: {
          name: botName,
          workflow,
          template: selectedTemplate,
          status: 'active',
          organizationId: organizationId!,
          userId: user!.id,
        },
      })
      message.success('Bot created successfully')
      refetch()
      setBotName('')
      setWorkflow('')
      setSelectedTemplate('')
    } catch (error) {
      message.error('Failed to create bot')
    }
  }

  const handleTestBot = async () => {
    try {
      const response = await generateResponse({ prompt: testPrompt })
      setTestResponse(response.answer)
    } catch (error) {
      message.error('Failed to test bot')
    }
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <Title level={2}>
          <i className="las la-robot" style={{ marginRight: 8 }}></i>
          Bot Builder
        </Title>
        <Text type="secondary">
          Create, customize, and test your AI-powered bots for voice and chat
          interactions.
        </Text>

        <Row gutter={[24, 24]} style={{ marginTop: 24 }}>
          <Col xs={24} lg={12}>
            <Card
              title={
                <>
                  <i className="las la-plus-circle"></i> Create New Bot
                </>
              }
            >
              <Space
                direction="vertical"
                style={{ width: '100%' }}
                size="large"
              >
                <Input
                  placeholder="Bot Name"
                  value={botName}
                  onChange={e => setBotName(e.target.value)}
                  prefix={<i className="las la-tag"></i>}
                />

                <Select
                  style={{ width: '100%' }}
                  placeholder="Select Bot Template"
                  value={selectedTemplate}
                  onChange={setSelectedTemplate}
                  options={templates}
                />

                <TextArea
                  rows={4}
                  placeholder="Define bot workflow and decision trees..."
                  value={workflow}
                  onChange={e => setWorkflow(e.target.value)}
                />

                <Button
                  type="primary"
                  onClick={handleCreateBot}
                  disabled={!botName || !selectedTemplate || !workflow}
                >
                  <i className="las la-save"></i> Create Bot
                </Button>
              </Space>
            </Card>
          </Col>

          <Col xs={24} lg={12}>
            <Card
              title={
                <>
                  <i className="las la-vial"></i> Test Bot
                </>
              }
            >
              <Space
                direction="vertical"
                style={{ width: '100%' }}
                size="large"
              >
                <TextArea
                  rows={3}
                  placeholder="Enter test prompt..."
                  value={testPrompt}
                  onChange={e => setTestPrompt(e.target.value)}
                />

                <Button
                  type="primary"
                  onClick={handleTestBot}
                  disabled={!testPrompt}
                >
                  <i className="las la-play"></i> Test Response
                </Button>

                {testResponse && (
                  <Card type="inner" title="Bot Response">
                    <Text>{testResponse}</Text>
                  </Card>
                )}
              </Space>
            </Card>
          </Col>
        </Row>

        <Card
          title={
            <>
              <i className="las la-list"></i> Existing Bots
            </>
          }
          style={{ marginTop: 24 }}
        >
          {bots?.map(bot => (
            <Card.Grid
              key={bot.id}
              style={{ width: '33.33%', textAlign: 'center' }}
            >
              <Space direction="vertical">
                <i className="las la-robot" style={{ fontSize: 24 }}></i>
                <Title level={5}>{bot.name}</Title>
                <Text type="secondary">Template: {bot.template}</Text>
                <Text type="secondary">Status: {bot.status}</Text>
              </Space>
            </Card.Grid>
          ))}
        </Card>
      </div>
    </PageLayout>
  )
}
