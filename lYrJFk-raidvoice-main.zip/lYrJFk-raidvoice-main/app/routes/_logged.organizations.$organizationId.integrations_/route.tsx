import { useUserContext } from '@/core/context'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'
import { useNango } from '@/plugins/nango/client'
import { useParams } from '@remix-run/react'
import {
  Button,
  Card,
  Form,
  Input,
  message,
  Space,
  Spin,
  Tabs,
  Typography,
} from 'antd'
import { useState } from 'react'
const { Title, Text } = Typography

export default function IntegrationsPage() {
  const { organization, checkOrganizationRole } = useUserContext()
  const { organizationId } = useParams()
  const [activeTab, setActiveTab] = useState('1')
  const nango = useNango()
  const isAdmin = checkOrganizationRole('owner')

  // Fetch integrations
  const {
    data: integrations,
    isLoading,
    refetch,
  } = Api.integration.findMany.useQuery({
    where: { organizationId },
    orderBy: { createdAt: 'desc' },
  })

  // Mutations
  const { mutateAsync: createIntegration } =
    Api.integration.create.useMutation()
  const { mutateAsync: updateIntegration } =
    Api.integration.update.useMutation()
  const { mutateAsync: deleteIntegration } =
    Api.integration.delete.useMutation()
  const { mutateAsync: nangoProxy } = Api.nango.proxy.useMutation()

  // Form handlers
  const handleApiKeySubmit = async (values: { apiKey: string }) => {
    try {
      await createIntegration({
        data: {
          type: 'VAPI_API_KEY',
          config: JSON.stringify({ apiKey: values.apiKey }),
          status: 'ACTIVE',
          webhookUrl: '',
          organizationId: organizationId!,
        },
      })
      message.success('API key saved successfully')
      refetch()
    } catch (error) {
      message.error('Failed to save API key')
    }
  }

  const handleWebhookSubmit = async (values: { url: string }) => {
    try {
      await createIntegration({
        data: {
          type: 'WEBHOOK',
          config: '{}',
          status: 'ACTIVE',
          webhookUrl: values.url,
          organizationId: organizationId!,
        },
      })
      message.success('Webhook configuration saved')
      refetch()
    } catch (error) {
      message.error('Failed to save webhook configuration')
    }
  }

  const connectThirdParty = async (provider: string) => {
    try {
      await nango.auth(provider, organization?.id)
      message.success(`Connected to ${provider} successfully`)
      refetch()
    } catch (error) {
      message.error(`Failed to connect to ${provider}`)
    }
  }

  const testConnection = async (integration: any) => {
    try {
      // Example test connection
      const config = {
        method: 'GET',
        endpoint: '/test-connection',
        providerConfigKey: integration.type.toLowerCase(),
        connectionId: organization?.id,
      }
      await nangoProxy(config)
      message.success('Connection test successful')
    } catch (error) {
      message.error('Connection test failed')
    }
  }

  if (isLoading) {
    return (
      <PageLayout layout="full-width">
        <div style={{ textAlign: 'center', padding: '50px' }}>
          <Spin size="large" />
        </div>
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '24px' }}>
        <Title level={2}>
          <i className="las la-plug" style={{ marginRight: '8px' }}></i>
          Integrations & Configuration
        </Title>
        <Text>
          Manage your API keys, integrations, and webhook configurations.
        </Text>

        <Tabs
          activeKey={activeTab}
          onChange={setActiveTab}
          style={{ marginTop: '24px' }}
        >
          <Tabs.TabPane tab="API Key Configuration" key="1">
            <Card>
              <Form onFinish={handleApiKeySubmit}>
                <Form.Item
                  label="Vapi.ai API Key"
                  name="apiKey"
                  rules={[
                    { required: true, message: 'Please input your API key!' },
                  ]}
                >
                  <Input.Password />
                </Form.Item>
                <Form.Item>
                  <Button type="primary" htmlType="submit">
                    <i
                      className="las la-save"
                      style={{ marginRight: '8px' }}
                    ></i>
                    Save API Key
                  </Button>
                </Form.Item>
              </Form>
            </Card>
          </Tabs.TabPane>

          <Tabs.TabPane tab="Third-Party Integrations" key="2">
            <Space direction="vertical" style={{ width: '100%' }} size="large">
              {['Salesforce', 'HubSpot', 'Zendesk'].map(provider => (
                <Card key={provider}>
                  <Space>
                    <i
                      className={`las la-${provider.toLowerCase()}`}
                      style={{ fontSize: '24px' }}
                    ></i>
                    <Title level={4} style={{ margin: 0 }}>
                      {provider}
                    </Title>
                    <Button
                      onClick={() => connectThirdParty(provider.toLowerCase())}
                    >
                      Connect {provider}
                    </Button>
                    <Button onClick={() => testConnection({ type: provider })}>
                      Test Connection
                    </Button>
                  </Space>
                </Card>
              ))}
            </Space>
          </Tabs.TabPane>

          <Tabs.TabPane tab="Webhook Configuration" key="3">
            <Card>
              <Form onFinish={handleWebhookSubmit}>
                <Form.Item
                  label="Webhook URL"
                  name="url"
                  rules={[
                    { required: true, message: 'Please input webhook URL!' },
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item>
                  <Button type="primary" htmlType="submit">
                    <i
                      className="las la-link"
                      style={{ marginRight: '8px' }}
                    ></i>
                    Save Webhook
                  </Button>
                </Form.Item>
              </Form>
            </Card>
          </Tabs.TabPane>
        </Tabs>
      </div>
    </PageLayout>
  )
}
