import {
  Typography,
  Table,
  Input,
  DatePicker,
  Select,
  Space,
  Button,
  Modal,
  message,
} from 'antd'
import { useState } from 'react'
const { Title, Text } = Typography
const { RangePicker } = DatePicker
const { Search } = Input
import { useUserContext } from '@/core/context'
import dayjs from 'dayjs'
import { useLocation, useNavigate, useParams } from '@remix-run/react'
import { useUploadPublic } from '@/plugins/upload/client'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function ConversationsPage() {
  const { organizationId } = useParams()
  const { checkOrganizationRole } = useUserContext()
  const isAdmin = checkOrganizationRole('owner')

  // States
  const [dateRange, setDateRange] = useState<
    [dayjs.Dayjs | null, dayjs.Dayjs | null]
  >([null, null])
  const [searchText, setSearchText] = useState('')
  const [type, setType] = useState<string>('')
  const [sentiment, setSentiment] = useState<string>('')
  const [selectedConversation, setSelectedConversation] = useState<any>(null)
  const [isModalVisible, setIsModalVisible] = useState(false)

  // Fetch conversations
  const { data: conversations, isLoading } = Api.conversation.findMany.useQuery(
    {
      where: {
        organizationId: organizationId as string,
        ...(searchText && {
          content: { contains: searchText, mode: 'insensitive' },
        }),
        ...(type && { type }),
        ...(sentiment && { sentiment }),
        ...(dateRange[0] &&
          dateRange[1] && {
            createdAt: {
              gte: dateRange[0].toDate(),
              lte: dateRange[1].toDate(),
            },
          }),
      },
      include: {
        user: true,
      },
    },
  )

  // Export functionality
  const handleExport = () => {
    if (!conversations) return

    const csvContent = conversations.map(conv => ({
      Date: dayjs(conv.createdAt).format('YYYY-MM-DD HH:mm'),
      Type: conv.type,
      Content: conv.content,
      Sentiment: conv.sentiment,
      User: conv.user?.name || 'Unknown',
    }))

    const csvString = [
      Object.keys(csvContent[0]).join(','),
      ...csvContent.map(row => Object.values(row).join(',')),
    ].join('\n')

    const blob = new Blob([csvString], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'conversations.csv'
    a.click()
    window.URL.revokeObjectURL(url)
    message.success('Export successful')
  }

  const columns = [
    {
      title: 'Date',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (date: string) => dayjs(date).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'User',
      dataIndex: 'user',
      key: 'user',
      render: (user: any) => user?.name || 'Unknown',
    },
    {
      title: 'Sentiment',
      dataIndex: 'sentiment',
      key: 'sentiment',
      render: (sentiment: string) => (
        <Text
          type={
            sentiment === 'POSITIVE'
              ? 'success'
              : sentiment === 'NEGATIVE'
              ? 'danger'
              : 'warning'
          }
        >
          {sentiment}
        </Text>
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (record: any) => (
        <Space>
          <Button
            type="link"
            onClick={() => {
              setSelectedConversation(record)
              setIsModalVisible(true)
            }}
          >
            <i className="las la-eye" /> View
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="full-width">
      <div style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
        <Title level={2}>
          <i className="las la-comments" /> Conversation History
        </Title>
        <Text type="secondary">
          View and manage all conversations across different channels
        </Text>

        <div style={{ marginTop: '24px' }}>
          <Space direction="vertical" size="middle" style={{ width: '100%' }}>
            <Space wrap>
              <RangePicker
                onChange={dates =>
                  setDateRange(
                    dates as [dayjs.Dayjs | null, dayjs.Dayjs | null],
                  )
                }
              />
              <Select
                style={{ width: 200 }}
                placeholder="Select Type"
                onChange={setType}
                allowClear
              >
                <Select.Option value="CHAT">Chat</Select.Option>
                <Select.Option value="VOICE">Voice</Select.Option>
                <Select.Option value="EMAIL">Email</Select.Option>
              </Select>
              <Select
                style={{ width: 200 }}
                placeholder="Select Sentiment"
                onChange={setSentiment}
                allowClear
              >
                <Select.Option value="POSITIVE">Positive</Select.Option>
                <Select.Option value="NEUTRAL">Neutral</Select.Option>
                <Select.Option value="NEGATIVE">Negative</Select.Option>
              </Select>
              <Search
                placeholder="Search conversations..."
                style={{ width: 300 }}
                onChange={e => setSearchText(e.target.value)}
              />
              {isAdmin && (
                <Button type="primary" onClick={handleExport}>
                  <i className="las la-file-export" /> Export
                </Button>
              )}
            </Space>

            <Table
              columns={columns}
              dataSource={conversations}
              loading={isLoading}
              rowKey="id"
            />
          </Space>
        </div>

        <Modal
          title="Conversation Details"
          open={isModalVisible}
          onCancel={() => setIsModalVisible(false)}
          footer={null}
          width={800}
        >
          {selectedConversation && (
            <Space direction="vertical" style={{ width: '100%' }}>
              <Text strong>Date:</Text>
              <Text>
                {dayjs(selectedConversation.createdAt).format(
                  'YYYY-MM-DD HH:mm',
                )}
              </Text>

              <Text strong>Type:</Text>
              <Text>{selectedConversation.type}</Text>

              {selectedConversation.recordingUrl && (
                <>
                  <Text strong>Recording:</Text>
                  <audio controls src={selectedConversation.recordingUrl} />
                </>
              )}

              <Text strong>Content:</Text>
              <Text>{selectedConversation.content}</Text>

              <Text strong>Sentiment:</Text>
              <Text>{selectedConversation.sentiment}</Text>
            </Space>
          )}
        </Modal>
      </div>
    </PageLayout>
  )
}
