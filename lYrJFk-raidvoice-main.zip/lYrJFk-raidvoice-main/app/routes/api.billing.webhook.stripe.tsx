import { PaymentServer } from '~/plugins/payment/server'

export const action = PaymentServer.actionWebhookStripe
