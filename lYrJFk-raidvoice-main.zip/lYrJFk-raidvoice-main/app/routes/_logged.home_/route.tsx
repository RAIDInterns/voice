import {
  Typography,
  Card,
  Row,
  Col,
  Statistic,
  Button,
  List,
  Badge,
  Space,
  Alert,
} from 'antd'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import dayjs from 'dayjs'
import { useLocation, useNavigate, useParams } from '@remix-run/react'
import { useUploadPublic } from '@/plugins/upload/client'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function DashboardPage() {
  const navigate = useNavigate()
  const { user, organization } = useUserContext()

  // Fetch recent conversations
  const { data: conversations } = Api.conversation.findMany.useQuery({
    where: { userId: user?.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
  })

  // Fetch credit transactions
  const { data: creditTransactions } = Api.creditTransaction.findMany.useQuery({
    where: { userId: user?.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
  })

  // Calculate total credits
  const totalCredits =
    creditTransactions?.reduce(
      (acc, transaction) =>
        acc +
        (transaction.type === 'CREDIT'
          ? transaction.amount
          : -transaction.amount),
      0,
    ) || 0

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <Title level={2}>Welcome to Your Dashboard</Title>
        <Text>
          Manage your conversations, monitor credits, and access quick actions
          all in one place.
        </Text>

        {/* Quick Actions */}
        <Row gutter={[16, 16]} style={{ marginTop: 24 }}>
          <Col xs={24} sm={12} md={6}>
            <Card
              hoverable
              onClick={() =>
                navigate(`/organizations/${organization?.id}/bot-builder`)
              }
            >
              <Space
                direction="vertical"
                align="center"
                style={{ width: '100%' }}
              >
                <i className="las la-robot" style={{ fontSize: 32 }} />
                <Text strong>Create Bot</Text>
              </Space>
            </Card>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <Card
              hoverable
              onClick={() =>
                navigate(`/organizations/${organization?.id}/conversations`)
              }
            >
              <Space
                direction="vertical"
                align="center"
                style={{ width: '100%' }}
              >
                <i className="las la-comments" style={{ fontSize: 32 }} />
                <Text strong>View Conversations</Text>
              </Space>
            </Card>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <Card
              hoverable
              onClick={() =>
                navigate(`/organizations/${organization?.id}/integrations`)
              }
            >
              <Space
                direction="vertical"
                align="center"
                style={{ width: '100%' }}
              >
                <i className="las la-plug" style={{ fontSize: 32 }} />
                <Text strong>Configure Integrations</Text>
              </Space>
            </Card>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <Card
              hoverable
              onClick={() =>
                navigate(`/organizations/${organization?.id}/credits`)
              }
            >
              <Space
                direction="vertical"
                align="center"
                style={{ width: '100%' }}
              >
                <i className="las la-coins" style={{ fontSize: 32 }} />
                <Text strong>Buy Credits</Text>
              </Space>
            </Card>
          </Col>
        </Row>

        {/* Credits and Usage */}
        <Row gutter={[16, 16]} style={{ marginTop: 24 }}>
          <Col xs={24} md={12}>
            <Card
              title={
                <Space>
                  <i className="las la-wallet" />
                  <span>Credits Overview</span>
                </Space>
              }
            >
              <Statistic
                title="Available Credits"
                value={totalCredits}
                precision={2}
                prefix={<i className="las la-coins" />}
              />
              <List
                size="small"
                style={{ marginTop: 16 }}
                dataSource={creditTransactions}
                renderItem={item => (
                  <List.Item>
                    <Text>{item.type}</Text>
                    <Text type={item.type === 'CREDIT' ? 'success' : 'danger'}>
                      {item.type === 'CREDIT' ? '+' : '-'}
                      {item.amount.toString()}
                    </Text>
                  </List.Item>
                )}
              />
            </Card>
          </Col>
          <Col xs={24} md={12}>
            <Card
              title={
                <Space>
                  <i className="las la-history" />
                  <span>Recent Conversations</span>
                </Space>
              }
            >
              <List
                dataSource={conversations}
                renderItem={conversation => (
                  <List.Item>
                    <Space>
                      <Badge
                        status={
                          conversation.status === 'ACTIVE'
                            ? 'processing'
                            : 'default'
                        }
                      />
                      <Text>{conversation.type}</Text>
                      <Text type="secondary">
                        {dayjs(conversation.createdAt).format('MMM D, YYYY')}
                      </Text>
                    </Space>
                  </List.Item>
                )}
              />
            </Card>
          </Col>
        </Row>

        {/* Notifications */}
        <Row style={{ marginTop: 24 }}>
          <Col span={24}>
            <Alert
              message="System Notification"
              description="Welcome to your dashboard! Start by creating a bot or exploring your conversations."
              type="info"
              showIcon
              icon={<i className="las la-bell" />}
            />
          </Col>
        </Row>
      </div>
    </PageLayout>
  )
}
