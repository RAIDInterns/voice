import { useUserContext } from '@/core/context'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'
import { useParams } from '@remix-run/react'
import {
  Button,
  Card,
  Col,
  Form,
  Input,
  InputNumber,
  message,
  Modal,
  Row,
  Switch,
  Table,
  Typography,
} from 'antd'
import dayjs from 'dayjs'
import { useState } from 'react'
const { Title, Text } = Typography

export default function CreditsPage() {
  const { organizationId } = useParams()
  const { user, checkOrganizationRole } = useUserContext()
  const [isAutoRechargeModalVisible, setIsAutoRechargeModalVisible] =
    useState(false)
  const [isAllocateModalVisible, setIsAllocateModalVisible] = useState(false)
  const [isStripeModalVisible, setIsStripeModalVisible] = useState(false)
  const isAdmin = checkOrganizationRole('owner')

  // Fetch credit transactions
  const { data: transactions } = Api.creditTransaction.findMany.useQuery({
    where: { organizationId },
    orderBy: { createdAt: 'desc' },
  })

  // Fetch current balance
  const currentBalance =
    transactions?.reduce((acc, curr) => acc + curr.amount, 0) || 0

  // Purchase credits mutation
  const { mutateAsync: createPaymentLink } =
    Api.billing.createPaymentLink.useMutation()

  const handlePurchaseCredits = async (productId: string) => {
    try {
      const paymentLink = await createPaymentLink({ productId })
      window.location.href = paymentLink.url
    } catch (error) {
      message.error('Failed to create payment link')
    }
  }

  const columns = [
    {
      title: 'Date',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (date: string) => dayjs(date).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount: number) => amount.toString(),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
    },
  ]

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <Title level={2}>
          <i className="las la-coins" style={{ marginRight: 8 }}></i>
          Credits Management
        </Title>
        <Text>Manage your credits, purchase more, and view usage history</Text>

        <Row gutter={[24, 24]} style={{ marginTop: 24 }}>
          <Col xs={24} lg={8}>
            <Card>
              <Title level={4}>Current Balance</Title>
              <Text style={{ fontSize: 32 }}>
                <i
                  className="las la-credit-card"
                  style={{ marginRight: 8 }}
                ></i>
                {currentBalance.toString()} credits
              </Text>
              <Button
                type="primary"
                block
                style={{ marginTop: 16 }}
                onClick={() => handlePurchaseCredits('credits_pack')}
              >
                <i className="las la-plus-circle"></i> Purchase Credits
              </Button>
            </Card>
          </Col>

          <Col xs={24} lg={8}>
            <Card>
              <Title level={4}>Auto-Recharge</Title>
              <Button block onClick={() => setIsAutoRechargeModalVisible(true)}>
                <i className="las la-sync"></i> Configure Auto-Recharge
              </Button>
            </Card>
          </Col>

          {isAdmin && (
            <Col xs={24} lg={8}>
              <Card>
                <Title level={4}>Admin Actions</Title>
                <Button
                  block
                  style={{ marginBottom: 16 }}
                  onClick={() => setIsAllocateModalVisible(true)}
                >
                  <i className="las la-user-friends"></i> Allocate Credits
                </Button>
                <Button block onClick={() => setIsStripeModalVisible(true)}>
                  <i className="las la-cog"></i> Stripe Settings
                </Button>
              </Card>
            </Col>
          )}
        </Row>

        <Card style={{ marginTop: 24 }}>
          <Title level={4}>Transaction History</Title>
          <Table
            columns={columns}
            dataSource={transactions}
            rowKey="id"
            pagination={{ pageSize: 10 }}
          />
        </Card>

        {/* Modals */}
        <Modal
          title="Configure Auto-Recharge"
          open={isAutoRechargeModalVisible}
          onCancel={() => setIsAutoRechargeModalVisible(false)}
          footer={null}
        >
          <Form layout="vertical">
            <Form.Item label="Minimum Balance Threshold">
              <InputNumber min={0} style={{ width: '100%' }} />
            </Form.Item>
            <Form.Item label="Auto-Recharge Amount">
              <InputNumber min={0} style={{ width: '100%' }} />
            </Form.Item>
            <Form.Item label="Enable Auto-Recharge">
              <Switch />
            </Form.Item>
            <Button type="primary" block>
              Save Settings
            </Button>
          </Form>
        </Modal>

        <Modal
          title="Allocate Credits"
          open={isAllocateModalVisible}
          onCancel={() => setIsAllocateModalVisible(false)}
          footer={null}
        >
          <Form layout="vertical">
            <Form.Item label="User Email">
              <Input />
            </Form.Item>
            <Form.Item label="Credit Amount">
              <InputNumber min={0} style={{ width: '100%' }} />
            </Form.Item>
            <Button type="primary" block>
              Allocate Credits
            </Button>
          </Form>
        </Modal>

        <Modal
          title="Stripe Settings"
          open={isStripeModalVisible}
          onCancel={() => setIsStripeModalVisible(false)}
          footer={null}
        >
          <Form layout="vertical">
            <Form.Item label="Stripe Public Key">
              <Input />
            </Form.Item>
            <Form.Item label="Stripe Secret Key">
              <Input.Password />
            </Form.Item>
            <Button type="primary" block>
              Save Keys
            </Button>
          </Form>
        </Modal>
      </div>
    </PageLayout>
  )
}
