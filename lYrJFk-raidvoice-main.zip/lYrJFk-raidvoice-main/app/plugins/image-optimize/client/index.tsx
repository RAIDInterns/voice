import { ImageSafe } from './ImageSafe'

export const ImageOptimizedClient = {
  Img: ImageSafe,
}
