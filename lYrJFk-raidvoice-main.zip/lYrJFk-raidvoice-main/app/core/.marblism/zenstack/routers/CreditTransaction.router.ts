/* eslint-disable */
import { type RouterFactory, type ProcBuilder, type BaseConfig, db } from ".";
import * as _Schema from '@zenstackhq/runtime/zod/input';
const $Schema: typeof _Schema = (_Schema as any).default ?? _Schema;
import { checkRead, checkMutate } from '../helper';
import type { Prisma } from '@zenstackhq/runtime/models';
import type { UseTRPCMutationOptions, UseTRPCMutationResult, UseTRPCQueryOptions, UseTRPCQueryResult, UseTRPCInfiniteQueryOptions, UseTRPCInfiniteQueryResult } from '@trpc/react-query/shared';
import type { TRPCClientErrorLike } from '@trpc/client';
import type { AnyRouter } from '@trpc/server';

export default function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({

        createMany: procedure.input($Schema.CreditTransactionInputSchema.createMany.optional()).mutation(async ({ ctx, input }) => checkMutate(db(ctx).creditTransaction.createMany(input as any))),

        create: procedure.input($Schema.CreditTransactionInputSchema.create).mutation(async ({ ctx, input }) => checkMutate(db(ctx).creditTransaction.create(input as any))),

        deleteMany: procedure.input($Schema.CreditTransactionInputSchema.deleteMany.optional()).mutation(async ({ ctx, input }) => checkMutate(db(ctx).creditTransaction.deleteMany(input as any))),

        delete: procedure.input($Schema.CreditTransactionInputSchema.delete).mutation(async ({ ctx, input }) => checkMutate(db(ctx).creditTransaction.delete(input as any))),

        findFirst: procedure.input($Schema.CreditTransactionInputSchema.findFirst.optional()).query(({ ctx, input }) => checkRead(db(ctx).creditTransaction.findFirst(input as any))),

        findMany: procedure.input($Schema.CreditTransactionInputSchema.findMany.optional()).query(({ ctx, input }) => checkRead(db(ctx).creditTransaction.findMany(input as any))),

        findUnique: procedure.input($Schema.CreditTransactionInputSchema.findUnique).query(({ ctx, input }) => checkRead(db(ctx).creditTransaction.findUnique(input as any))),

        updateMany: procedure.input($Schema.CreditTransactionInputSchema.updateMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).creditTransaction.updateMany(input as any))),

        update: procedure.input($Schema.CreditTransactionInputSchema.update).mutation(async ({ ctx, input }) => checkMutate(db(ctx).creditTransaction.update(input as any))),

        count: procedure.input($Schema.CreditTransactionInputSchema.count.optional()).query(({ ctx, input }) => checkRead(db(ctx).creditTransaction.count(input as any))),

    }
    );
}

export interface ClientType<AppRouter extends AnyRouter, Context = AppRouter['_def']['_config']['$types']['ctx']> {
    createMany: {

        useMutation: <T extends Prisma.CreditTransactionCreateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.CreditTransactionCreateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.CreditTransactionCreateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.CreditTransactionCreateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    create: {

        useMutation: <T extends Prisma.CreditTransactionCreateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.CreditTransactionCreateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.CreditTransactionGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.CreditTransactionGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.CreditTransactionCreateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.CreditTransactionCreateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.CreditTransactionGetPayload<T>, Context>) => Promise<Prisma.CreditTransactionGetPayload<T>>
            };

    };
    deleteMany: {

        useMutation: <T extends Prisma.CreditTransactionDeleteManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.CreditTransactionDeleteManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.CreditTransactionDeleteManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.CreditTransactionDeleteManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    delete: {

        useMutation: <T extends Prisma.CreditTransactionDeleteArgs>(opts?: UseTRPCMutationOptions<
            Prisma.CreditTransactionDeleteArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.CreditTransactionGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.CreditTransactionGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.CreditTransactionDeleteArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.CreditTransactionDeleteArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.CreditTransactionGetPayload<T>, Context>) => Promise<Prisma.CreditTransactionGetPayload<T>>
            };

    };
    findFirst: {

        useQuery: <T extends Prisma.CreditTransactionFindFirstArgs, TData = Prisma.CreditTransactionGetPayload<T>>(
            input?: Prisma.SelectSubset<T, Prisma.CreditTransactionFindFirstArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.CreditTransactionGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.CreditTransactionFindFirstArgs>(
            input?: Omit<Prisma.SelectSubset<T, Prisma.CreditTransactionFindFirstArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.CreditTransactionGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.CreditTransactionGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findMany: {

        useQuery: <T extends Prisma.CreditTransactionFindManyArgs, TData = Array<Prisma.CreditTransactionGetPayload<T>>>(
            input?: Prisma.SelectSubset<T, Prisma.CreditTransactionFindManyArgs>,
            opts?: UseTRPCQueryOptions<string, T, Array<Prisma.CreditTransactionGetPayload<T>>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.CreditTransactionFindManyArgs>(
            input?: Omit<Prisma.SelectSubset<T, Prisma.CreditTransactionFindManyArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Array<Prisma.CreditTransactionGetPayload<T>>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Array<Prisma.CreditTransactionGetPayload<T>>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findUnique: {

        useQuery: <T extends Prisma.CreditTransactionFindUniqueArgs, TData = Prisma.CreditTransactionGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.CreditTransactionFindUniqueArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.CreditTransactionGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.CreditTransactionFindUniqueArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.CreditTransactionFindUniqueArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.CreditTransactionGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.CreditTransactionGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    updateMany: {

        useMutation: <T extends Prisma.CreditTransactionUpdateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.CreditTransactionUpdateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.CreditTransactionUpdateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.CreditTransactionUpdateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    update: {

        useMutation: <T extends Prisma.CreditTransactionUpdateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.CreditTransactionUpdateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.CreditTransactionGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.CreditTransactionGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.CreditTransactionUpdateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.CreditTransactionUpdateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.CreditTransactionGetPayload<T>, Context>) => Promise<Prisma.CreditTransactionGetPayload<T>>
            };

    };
    count: {

        useQuery: <T extends Prisma.CreditTransactionCountArgs, TData = 'select' extends keyof T
            ? T['select'] extends true
            ? number
            : Prisma.GetScalarType<T['select'], Prisma.CreditTransactionCountAggregateOutputType>
            : number>(
                input?: Prisma.Subset<T, Prisma.CreditTransactionCountArgs>,
                opts?: UseTRPCQueryOptions<string, T, 'select' extends keyof T
                    ? T['select'] extends true
                    ? number
                    : Prisma.GetScalarType<T['select'], Prisma.CreditTransactionCountAggregateOutputType>
                    : number, TData, Error>
            ) => UseTRPCQueryResult<
                TData,
                TRPCClientErrorLike<AppRouter>
            >;
        useInfiniteQuery: <T extends Prisma.CreditTransactionCountArgs>(
            input?: Omit<Prisma.Subset<T, Prisma.CreditTransactionCountArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, 'select' extends keyof T
                ? T['select'] extends true
                ? number
                : Prisma.GetScalarType<T['select'], Prisma.CreditTransactionCountAggregateOutputType>
                : number, Error>
        ) => UseTRPCInfiniteQueryResult<
            'select' extends keyof T
            ? T['select'] extends true
            ? number
            : Prisma.GetScalarType<T['select'], Prisma.CreditTransactionCountAggregateOutputType>
            : number,
            TRPCClientErrorLike<AppRouter>
        >;

    };
}
