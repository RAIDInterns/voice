/* eslint-disable */
import { type RouterFactory, type ProcBuilder, type BaseConfig, db } from ".";
import * as _Schema from '@zenstackhq/runtime/zod/input';
const $Schema: typeof _Schema = (_Schema as any).default ?? _Schema;
import { checkRead, checkMutate } from '../helper';
import type { Prisma } from '@zenstackhq/runtime/models';
import type { UseTRPCMutationOptions, UseTRPCMutationResult, UseTRPCQueryOptions, UseTRPCQueryResult, UseTRPCInfiniteQueryOptions, UseTRPCInfiniteQueryResult } from '@trpc/react-query/shared';
import type { TRPCClientErrorLike } from '@trpc/client';
import type { AnyRouter } from '@trpc/server';

export default function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({

        createMany: procedure.input($Schema.WidgetInputSchema.createMany.optional()).mutation(async ({ ctx, input }) => checkMutate(db(ctx).widget.createMany(input as any))),

        create: procedure.input($Schema.WidgetInputSchema.create).mutation(async ({ ctx, input }) => checkMutate(db(ctx).widget.create(input as any))),

        deleteMany: procedure.input($Schema.WidgetInputSchema.deleteMany.optional()).mutation(async ({ ctx, input }) => checkMutate(db(ctx).widget.deleteMany(input as any))),

        delete: procedure.input($Schema.WidgetInputSchema.delete).mutation(async ({ ctx, input }) => checkMutate(db(ctx).widget.delete(input as any))),

        findFirst: procedure.input($Schema.WidgetInputSchema.findFirst.optional()).query(({ ctx, input }) => checkRead(db(ctx).widget.findFirst(input as any))),

        findMany: procedure.input($Schema.WidgetInputSchema.findMany.optional()).query(({ ctx, input }) => checkRead(db(ctx).widget.findMany(input as any))),

        findUnique: procedure.input($Schema.WidgetInputSchema.findUnique).query(({ ctx, input }) => checkRead(db(ctx).widget.findUnique(input as any))),

        updateMany: procedure.input($Schema.WidgetInputSchema.updateMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).widget.updateMany(input as any))),

        update: procedure.input($Schema.WidgetInputSchema.update).mutation(async ({ ctx, input }) => checkMutate(db(ctx).widget.update(input as any))),

        count: procedure.input($Schema.WidgetInputSchema.count.optional()).query(({ ctx, input }) => checkRead(db(ctx).widget.count(input as any))),

    }
    );
}

export interface ClientType<AppRouter extends AnyRouter, Context = AppRouter['_def']['_config']['$types']['ctx']> {
    createMany: {

        useMutation: <T extends Prisma.WidgetCreateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.WidgetCreateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.WidgetCreateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.WidgetCreateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    create: {

        useMutation: <T extends Prisma.WidgetCreateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.WidgetCreateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.WidgetGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.WidgetGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.WidgetCreateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.WidgetCreateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.WidgetGetPayload<T>, Context>) => Promise<Prisma.WidgetGetPayload<T>>
            };

    };
    deleteMany: {

        useMutation: <T extends Prisma.WidgetDeleteManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.WidgetDeleteManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.WidgetDeleteManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.WidgetDeleteManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    delete: {

        useMutation: <T extends Prisma.WidgetDeleteArgs>(opts?: UseTRPCMutationOptions<
            Prisma.WidgetDeleteArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.WidgetGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.WidgetGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.WidgetDeleteArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.WidgetDeleteArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.WidgetGetPayload<T>, Context>) => Promise<Prisma.WidgetGetPayload<T>>
            };

    };
    findFirst: {

        useQuery: <T extends Prisma.WidgetFindFirstArgs, TData = Prisma.WidgetGetPayload<T>>(
            input?: Prisma.SelectSubset<T, Prisma.WidgetFindFirstArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.WidgetGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.WidgetFindFirstArgs>(
            input?: Omit<Prisma.SelectSubset<T, Prisma.WidgetFindFirstArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.WidgetGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.WidgetGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findMany: {

        useQuery: <T extends Prisma.WidgetFindManyArgs, TData = Array<Prisma.WidgetGetPayload<T>>>(
            input?: Prisma.SelectSubset<T, Prisma.WidgetFindManyArgs>,
            opts?: UseTRPCQueryOptions<string, T, Array<Prisma.WidgetGetPayload<T>>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.WidgetFindManyArgs>(
            input?: Omit<Prisma.SelectSubset<T, Prisma.WidgetFindManyArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Array<Prisma.WidgetGetPayload<T>>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Array<Prisma.WidgetGetPayload<T>>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findUnique: {

        useQuery: <T extends Prisma.WidgetFindUniqueArgs, TData = Prisma.WidgetGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.WidgetFindUniqueArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.WidgetGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.WidgetFindUniqueArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.WidgetFindUniqueArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.WidgetGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.WidgetGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    updateMany: {

        useMutation: <T extends Prisma.WidgetUpdateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.WidgetUpdateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.WidgetUpdateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.WidgetUpdateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    update: {

        useMutation: <T extends Prisma.WidgetUpdateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.WidgetUpdateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.WidgetGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.WidgetGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.WidgetUpdateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.WidgetUpdateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.WidgetGetPayload<T>, Context>) => Promise<Prisma.WidgetGetPayload<T>>
            };

    };
    count: {

        useQuery: <T extends Prisma.WidgetCountArgs, TData = 'select' extends keyof T
            ? T['select'] extends true
            ? number
            : Prisma.GetScalarType<T['select'], Prisma.WidgetCountAggregateOutputType>
            : number>(
                input?: Prisma.Subset<T, Prisma.WidgetCountArgs>,
                opts?: UseTRPCQueryOptions<string, T, 'select' extends keyof T
                    ? T['select'] extends true
                    ? number
                    : Prisma.GetScalarType<T['select'], Prisma.WidgetCountAggregateOutputType>
                    : number, TData, Error>
            ) => UseTRPCQueryResult<
                TData,
                TRPCClientErrorLike<AppRouter>
            >;
        useInfiniteQuery: <T extends Prisma.WidgetCountArgs>(
            input?: Omit<Prisma.Subset<T, Prisma.WidgetCountArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, 'select' extends keyof T
                ? T['select'] extends true
                ? number
                : Prisma.GetScalarType<T['select'], Prisma.WidgetCountAggregateOutputType>
                : number, Error>
        ) => UseTRPCInfiniteQueryResult<
            'select' extends keyof T
            ? T['select'] extends true
            ? number
            : Prisma.GetScalarType<T['select'], Prisma.WidgetCountAggregateOutputType>
            : number,
            TRPCClientErrorLike<AppRouter>
        >;

    };
}
