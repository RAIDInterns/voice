/* eslint-disable */
import { type RouterFactory, type ProcBuilder, type BaseConfig, db } from ".";
import * as _Schema from '@zenstackhq/runtime/zod/input';
const $Schema: typeof _Schema = (_Schema as any).default ?? _Schema;
import { checkRead, checkMutate } from '../helper';
import type { Prisma } from '@zenstackhq/runtime/models';
import type { UseTRPCMutationOptions, UseTRPCMutationResult, UseTRPCQueryOptions, UseTRPCQueryResult, UseTRPCInfiniteQueryOptions, UseTRPCInfiniteQueryResult } from '@trpc/react-query/shared';
import type { TRPCClientErrorLike } from '@trpc/client';
import type { AnyRouter } from '@trpc/server';

export default function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({

        createMany: procedure.input($Schema.BotInputSchema.createMany.optional()).mutation(async ({ ctx, input }) => checkMutate(db(ctx).bot.createMany(input as any))),

        create: procedure.input($Schema.BotInputSchema.create).mutation(async ({ ctx, input }) => checkMutate(db(ctx).bot.create(input as any))),

        deleteMany: procedure.input($Schema.BotInputSchema.deleteMany.optional()).mutation(async ({ ctx, input }) => checkMutate(db(ctx).bot.deleteMany(input as any))),

        delete: procedure.input($Schema.BotInputSchema.delete).mutation(async ({ ctx, input }) => checkMutate(db(ctx).bot.delete(input as any))),

        findFirst: procedure.input($Schema.BotInputSchema.findFirst.optional()).query(({ ctx, input }) => checkRead(db(ctx).bot.findFirst(input as any))),

        findMany: procedure.input($Schema.BotInputSchema.findMany.optional()).query(({ ctx, input }) => checkRead(db(ctx).bot.findMany(input as any))),

        findUnique: procedure.input($Schema.BotInputSchema.findUnique).query(({ ctx, input }) => checkRead(db(ctx).bot.findUnique(input as any))),

        updateMany: procedure.input($Schema.BotInputSchema.updateMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).bot.updateMany(input as any))),

        update: procedure.input($Schema.BotInputSchema.update).mutation(async ({ ctx, input }) => checkMutate(db(ctx).bot.update(input as any))),

        count: procedure.input($Schema.BotInputSchema.count.optional()).query(({ ctx, input }) => checkRead(db(ctx).bot.count(input as any))),

    }
    );
}

export interface ClientType<AppRouter extends AnyRouter, Context = AppRouter['_def']['_config']['$types']['ctx']> {
    createMany: {

        useMutation: <T extends Prisma.BotCreateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.BotCreateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.BotCreateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.BotCreateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    create: {

        useMutation: <T extends Prisma.BotCreateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.BotCreateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BotGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BotGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.BotCreateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.BotCreateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BotGetPayload<T>, Context>) => Promise<Prisma.BotGetPayload<T>>
            };

    };
    deleteMany: {

        useMutation: <T extends Prisma.BotDeleteManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.BotDeleteManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.BotDeleteManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.BotDeleteManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    delete: {

        useMutation: <T extends Prisma.BotDeleteArgs>(opts?: UseTRPCMutationOptions<
            Prisma.BotDeleteArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BotGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BotGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.BotDeleteArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.BotDeleteArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BotGetPayload<T>, Context>) => Promise<Prisma.BotGetPayload<T>>
            };

    };
    findFirst: {

        useQuery: <T extends Prisma.BotFindFirstArgs, TData = Prisma.BotGetPayload<T>>(
            input?: Prisma.SelectSubset<T, Prisma.BotFindFirstArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.BotGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.BotFindFirstArgs>(
            input?: Omit<Prisma.SelectSubset<T, Prisma.BotFindFirstArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.BotGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.BotGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findMany: {

        useQuery: <T extends Prisma.BotFindManyArgs, TData = Array<Prisma.BotGetPayload<T>>>(
            input?: Prisma.SelectSubset<T, Prisma.BotFindManyArgs>,
            opts?: UseTRPCQueryOptions<string, T, Array<Prisma.BotGetPayload<T>>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.BotFindManyArgs>(
            input?: Omit<Prisma.SelectSubset<T, Prisma.BotFindManyArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Array<Prisma.BotGetPayload<T>>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Array<Prisma.BotGetPayload<T>>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findUnique: {

        useQuery: <T extends Prisma.BotFindUniqueArgs, TData = Prisma.BotGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.BotFindUniqueArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.BotGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.BotFindUniqueArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.BotFindUniqueArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.BotGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.BotGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    updateMany: {

        useMutation: <T extends Prisma.BotUpdateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.BotUpdateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.BotUpdateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.BotUpdateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    update: {

        useMutation: <T extends Prisma.BotUpdateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.BotUpdateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BotGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BotGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.BotUpdateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.BotUpdateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BotGetPayload<T>, Context>) => Promise<Prisma.BotGetPayload<T>>
            };

    };
    count: {

        useQuery: <T extends Prisma.BotCountArgs, TData = 'select' extends keyof T
            ? T['select'] extends true
            ? number
            : Prisma.GetScalarType<T['select'], Prisma.BotCountAggregateOutputType>
            : number>(
                input?: Prisma.Subset<T, Prisma.BotCountArgs>,
                opts?: UseTRPCQueryOptions<string, T, 'select' extends keyof T
                    ? T['select'] extends true
                    ? number
                    : Prisma.GetScalarType<T['select'], Prisma.BotCountAggregateOutputType>
                    : number, TData, Error>
            ) => UseTRPCQueryResult<
                TData,
                TRPCClientErrorLike<AppRouter>
            >;
        useInfiniteQuery: <T extends Prisma.BotCountArgs>(
            input?: Omit<Prisma.Subset<T, Prisma.BotCountArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, 'select' extends keyof T
                ? T['select'] extends true
                ? number
                : Prisma.GetScalarType<T['select'], Prisma.BotCountAggregateOutputType>
                : number, Error>
        ) => UseTRPCInfiniteQueryResult<
            'select' extends keyof T
            ? T['select'] extends true
            ? number
            : Prisma.GetScalarType<T['select'], Prisma.BotCountAggregateOutputType>
            : number,
            TRPCClientErrorLike<AppRouter>
        >;

    };
}
