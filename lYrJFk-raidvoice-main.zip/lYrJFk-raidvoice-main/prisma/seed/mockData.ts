import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const splitSql = (sql: string) => {
  return sql.split(';').filter(content => content.trim() !== '')
}

async function main() {
  const sql = `

INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('aae38065-64c9-488f-9601-7d74b090de4e', '9Wilfred.Batz17@yahoo.com', 'Jane Smith', 'https://i.imgur.com/YfJQV5z.png?id=11', 'inv123abc', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('7c071efd-55ae-4e52-9078-7b36e2ca2553', '17Elizabeth_Stracke77@hotmail.com', 'Jane Smith', 'https://i.imgur.com/YfJQV5z.png?id=19', 'inv456def', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('fc4fa4ef-66c3-44bd-8e2c-668bbd863971', '25Hunter.Kling@yahoo.com', 'Emily Watson', 'https://i.imgur.com/YfJQV5z.png?id=27', 'inv789ghi', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('5e8be189-78c9-4f4a-b5cd-5a81d5134fa6', '33Adan_Steuber47@gmail.com', 'Emily Watson', 'https://i.imgur.com/YfJQV5z.png?id=35', 'inv345mno', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('28a179a5-e49c-4555-a893-f7dc6833f88c', '41Norma82@yahoo.com', 'Jane Smith', 'https://i.imgur.com/YfJQV5z.png?id=43', 'inv456def', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('a8bc79c7-dbc0-46b1-adc2-6bfde25e625d', '49Davonte49@gmail.com', 'John Doe', 'https://i.imgur.com/YfJQV5z.png?id=51', 'inv123abc', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('3b1b81f4-969d-45d8-aa3e-8f673bd0d69c', '57Stanton_Green@gmail.com', 'Emily Watson', 'https://i.imgur.com/YfJQV5z.png?id=59', 'inv789ghi', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('d0468694-8a7a-4af3-ae42-9f931d274e05', '65Terry_Donnelly27@gmail.com', 'Alex Jones', 'https://i.imgur.com/YfJQV5z.png?id=67', 'inv123abc', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "status", "globalRole", "password") VALUES ('683d5d6a-0622-4834-8cca-ad0849e68f83', '73Dagmar48@hotmail.com', 'Jane Smith', 'https://i.imgur.com/YfJQV5z.png?id=75', 'inv789ghi', 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('a84f7f4e-4161-452a-b2a2-82d15e02a226', 'Tech Innovators Inc.', 'https://i.imgur.com/YfJQV5z.png?id=82');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('6faa556f-7f00-45cf-96e1-0d7e1ce7aa8c', 'Future Vision Group', 'https://i.imgur.com/YfJQV5z.png?id=85');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('397d7006-f4d5-446d-aafe-9c00e287a866', 'Tech Innovators Inc.', 'https://i.imgur.com/YfJQV5z.png?id=88');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('c1f9c253-9585-416f-a7be-28937430caca', 'NextGen Enterprises', 'https://i.imgur.com/YfJQV5z.png?id=91');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('fe14e62f-78e1-4142-b2f8-0a58e20a3e42', 'Global Solutions LLC', 'https://i.imgur.com/YfJQV5z.png?id=94');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('53d08390-ea5e-4686-beb6-aa71e3bcc10d', 'Tech Innovators Inc.', 'https://i.imgur.com/YfJQV5z.png?id=97');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('cff2876e-2b8d-4b8f-9afb-499218ffbb84', 'NextGen Enterprises', 'https://i.imgur.com/YfJQV5z.png?id=100');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('22c59b85-34c0-4a02-867a-345767f8c4b4', 'Global Solutions LLC', 'https://i.imgur.com/YfJQV5z.png?id=103');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('2c84abf4-3186-4dc9-8afe-32a7bb6adab0', 'Tech Innovators Inc.', 'https://i.imgur.com/YfJQV5z.png?id=106');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('1548d032-f227-4eb9-a9bd-0883e402964a', 'NextGen Enterprises', 'https://i.imgur.com/YfJQV5z.png?id=109');

INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('2d4706c8-5d5b-44c6-8027-7c79730af76a', 'User', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '53d08390-ea5e-4686-beb6-aa71e3bcc10d');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('fe52aa24-b1ba-4e15-b3fe-308557a69bcb', 'Sales Manager', '3b1b81f4-969d-45d8-aa3e-8f673bd0d69c', '397d7006-f4d5-446d-aafe-9c00e287a866');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('cea1011b-d8a9-4a88-b67c-0f494e4d95d8', 'Admin', 'fc4fa4ef-66c3-44bd-8e2c-668bbd863971', '1548d032-f227-4eb9-a9bd-0883e402964a');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('3bbb0fcf-65f0-4e8d-9bb8-3c8b3348baaa', 'Sales Manager', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'cff2876e-2b8d-4b8f-9afb-499218ffbb84');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('d82f3889-3452-4296-9eb6-1b2e7a91efa1', 'Sales Manager', 'd0468694-8a7a-4af3-ae42-9f931d274e05', '6faa556f-7f00-45cf-96e1-0d7e1ce7aa8c');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('a26fe6ae-59a9-4f70-a848-bcc1e6317451', 'Super Admin', 'a8bc79c7-dbc0-46b1-adc2-6bfde25e625d', 'a84f7f4e-4161-452a-b2a2-82d15e02a226');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('18978631-5030-4af4-aca1-8d7210cd8536', 'Admin', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '6faa556f-7f00-45cf-96e1-0d7e1ce7aa8c');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('007aa4a5-862b-491c-9774-f8df761c260c', 'User', '7c071efd-55ae-4e52-9078-7b36e2ca2553', 'a84f7f4e-4161-452a-b2a2-82d15e02a226');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('7de3343e-2808-4dd3-8590-c86c612a4336', 'User', '28a179a5-e49c-4555-a893-f7dc6833f88c', 'cff2876e-2b8d-4b8f-9afb-499218ffbb84');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('c3b54b4a-6478-4bbc-85aa-1272898089f7', 'Support Specialist', 'd0468694-8a7a-4af3-ae42-9f931d274e05', 'fe14e62f-78e1-4142-b2f8-0a58e20a3e42');

INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('8d20d174-7fcf-4d48-8ba3-376247e62b28', 'Order Processing Bot', 'Booking Management', 'Appointment Booking', 'Deactivated', 'c1f9c253-9585-416f-a7be-28937430caca', '7c071efd-55ae-4e52-9078-7b36e2ca2553');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('b9f1dca0-fa34-40e4-987d-5e6a2bdec201', 'Customer Support Bot', 'Customer Inquiry', 'Feedback Gathering', 'Pending Activation', '53d08390-ea5e-4686-beb6-aa71e3bcc10d', 'a8bc79c7-dbc0-46b1-adc2-6bfde25e625d');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('e678ffc2-fc77-478d-aeea-de5d5a69a814', 'Sales Assistant', 'Lead Generation', 'Appointment Booking', 'Active', '53d08390-ea5e-4686-beb6-aa71e3bcc10d', 'd0468694-8a7a-4af3-ae42-9f931d274e05');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('546498f5-d4f7-42ad-93ec-98bf193354e2', 'Appointment Scheduler', 'Order Fulfillment', 'Appointment Booking', 'Pending Activation', '2c84abf4-3186-4dc9-8afe-32a7bb6adab0', 'd0468694-8a7a-4af3-ae42-9f931d274e05');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('2de85712-42ef-4caa-9de2-31e6a5e9e212', 'Sales Assistant', 'Lead Generation', 'Appointment Booking', 'Pending Activation', '1548d032-f227-4eb9-a9bd-0883e402964a', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('6a7ee4cd-c3c9-497c-8683-735e9fe009fc', 'Appointment Scheduler', 'Booking Management', 'Appointment Booking', 'Under Review', 'a84f7f4e-4161-452a-b2a2-82d15e02a226', 'd0468694-8a7a-4af3-ae42-9f931d274e05');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('5a651c76-49ff-4d4e-9d3c-2ea856a185ef', 'Appointment Scheduler', 'Customer Inquiry', 'Basic Support', 'Pending Activation', 'fe14e62f-78e1-4142-b2f8-0a58e20a3e42', 'aae38065-64c9-488f-9601-7d74b090de4e');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('dc298946-56f0-49a2-b8d2-683876093070', 'Order Processing Bot', 'Booking Management', 'Basic Support', 'Inactive', '22c59b85-34c0-4a02-867a-345767f8c4b4', '3b1b81f4-969d-45d8-aa3e-8f673bd0d69c');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('3fa8b6ad-f418-4ed3-87a0-a9fed66ca136', 'Feedback Collector', 'Order Fulfillment', 'Order Management', 'Active', '22c59b85-34c0-4a02-867a-345767f8c4b4', '683d5d6a-0622-4834-8cca-ad0849e68f83');
INSERT INTO "Bot" ("id", "name", "workflow", "template", "status", "organizationId", "userId") VALUES ('29eddbcb-90af-4a67-ba64-c14f4b31a6b5', 'Appointment Scheduler', 'Booking Management', 'Advanced Sales', 'Inactive', 'c1f9c253-9585-416f-a7be-28937430caca', 'd0468694-8a7a-4af3-ae42-9f931d274e05');

INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('b51036c2-40cf-4800-84a1-b2ecbbcd6b68', 'VoiceBot', 'apiKeyghi012timeout15', 'pending', 'https://i.imgur.com/YfJQV5z.png?id=184', '53d08390-ea5e-4686-beb6-aa71e3bcc10d');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('fce13d1c-2d2d-4b7d-b6bc-3cf377d34dbc', 'VoiceBot', 'apiKeyjkl345timeout90', 'failed', 'https://i.imgur.com/YfJQV5z.png?id=189', '53d08390-ea5e-4686-beb6-aa71e3bcc10d');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('f8359096-5692-4fa9-b80e-0ec9c13b3d61', 'ChatBot', 'apiKeyabc123timeout30', 'inactive', 'https://i.imgur.com/YfJQV5z.png?id=194', '2c84abf4-3186-4dc9-8afe-32a7bb6adab0');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('af60a6da-dd62-42cb-9200-055b7fc20c02', 'Email', 'apiKeydef456timeout45', 'failed', 'https://i.imgur.com/YfJQV5z.png?id=199', 'a84f7f4e-4161-452a-b2a2-82d15e02a226');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('f4b32c47-1bbc-416d-93b5-53331178d4e7', 'ChatBot', 'apiKeyghi012timeout15', 'pending', 'https://i.imgur.com/YfJQV5z.png?id=204', 'a84f7f4e-4161-452a-b2a2-82d15e02a226');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('bef74f35-ca73-477e-9638-2367248bfa20', 'SMS', 'apiKeyghi012timeout15', 'pending', 'https://i.imgur.com/YfJQV5z.png?id=209', '397d7006-f4d5-446d-aafe-9c00e287a866');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('a7b28b92-c841-42a3-be4e-930a7c97fbfa', 'VoiceBot', 'apiKeyghi012timeout15', 'inactive', 'https://i.imgur.com/YfJQV5z.png?id=214', '53d08390-ea5e-4686-beb6-aa71e3bcc10d');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('951ff370-a147-4475-afe5-fd54ab1e2948', 'CRM', 'apiKeyabc123timeout30', 'failed', 'https://i.imgur.com/YfJQV5z.png?id=219', '1548d032-f227-4eb9-a9bd-0883e402964a');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('fe376af7-af3c-45e2-972a-3f502450ec93', 'Email', 'apiKeyabc123timeout30', 'inactive', 'https://i.imgur.com/YfJQV5z.png?id=224', '53d08390-ea5e-4686-beb6-aa71e3bcc10d');
INSERT INTO "Integration" ("id", "type", "config", "status", "webhookUrl", "organizationId") VALUES ('208830e4-4345-47d3-94fa-fa18b992df04', 'Email', 'apiKeyjkl345timeout90', 'suspended', 'https://i.imgur.com/YfJQV5z.png?id=229', '53d08390-ea5e-4686-beb6-aa71e3bcc10d');

INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('c82d3d1b-9e09-4277-84e6-fad8c0f9e467', 'SmartChat', 'themecustomlanguagefrautoStarttrue', 'iframe srchttpsexample.comwidget2iframe', 'active', 'c1f9c253-9585-416f-a7be-28937430caca', '28a179a5-e49c-4555-a893-f7dc6833f88c');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('22c479b0-540e-4f45-b66b-1af0108c2f6e', 'ConnectBot', 'themecustomlanguagefrautoStarttrue', 'iframe srchttpsexample.comwidget3iframe', 'suspended', 'cff2876e-2b8d-4b8f-9afb-499218ffbb84', 'fc4fa4ef-66c3-44bd-8e2c-668bbd863971');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('09499d92-266b-4b80-ae2d-723d1aff98fd', 'EngageWidget', 'themelightlanguageitautoStarttrue', 'iframe srchttpsexample.comwidget3iframe', 'active', '22c59b85-34c0-4a02-867a-345767f8c4b4', 'a8bc79c7-dbc0-46b1-adc2-6bfde25e625d');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('fdd85407-ede9-4b3f-9912-57f65482926b', 'EngageWidget', 'themedarklanguagedeautoStartfalse', 'iframe srchttpsexample.comwidget1iframe', 'active', '22c59b85-34c0-4a02-867a-345767f8c4b4', '28a179a5-e49c-4555-a893-f7dc6833f88c');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('e2699fd1-6c00-4b51-80f2-06654a47540b', 'VoiceAssist 360', 'themecustomlanguagefrautoStarttrue', 'iframe srchttpsexample.comwidget2iframe', 'active', '2c84abf4-3186-4dc9-8afe-32a7bb6adab0', 'a8bc79c7-dbc0-46b1-adc2-6bfde25e625d');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('fb912430-b96d-4af7-b038-4adc0cc4df91', 'SmartChat', 'themedarklanguageenautoStarttrue', 'iframe srchttpsexample.comwidget5iframe', 'pending', '2c84abf4-3186-4dc9-8afe-32a7bb6adab0', '7c071efd-55ae-4e52-9078-7b36e2ca2553');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('39ac6d02-356d-4ee5-a7cf-eed695a7643e', 'ChatBot Pro', 'themelightlanguageitautoStarttrue', 'iframe srchttpsexample.comwidget5iframe', 'active', 'a84f7f4e-4161-452a-b2a2-82d15e02a226', 'a8bc79c7-dbc0-46b1-adc2-6bfde25e625d');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('0c3cb903-98a7-4197-9a2e-39c6b2595292', 'SmartChat', 'themelightlanguageitautoStarttrue', 'iframe srchttpsexample.comwidget5iframe', 'inactive', 'a84f7f4e-4161-452a-b2a2-82d15e02a226', 'fc4fa4ef-66c3-44bd-8e2c-668bbd863971');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('8a08bba3-fb8e-4c06-9037-8b80228df656', 'VoiceAssist 360', 'themedarklanguageenautoStarttrue', 'iframe srchttpsexample.comwidget2iframe', 'active', '53d08390-ea5e-4686-beb6-aa71e3bcc10d', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Widget" ("id", "name", "config", "embedCode", "status", "organizationId", "userId") VALUES ('db6cf7aa-0c2d-4241-9aec-6fbae0ef63b4', 'ChatBot Pro', 'themedarklanguagedeautoStartfalse', 'iframe srchttpsexample.comwidget3iframe', 'suspended', '1548d032-f227-4eb9-a9bd-0883e402964a', 'a8bc79c7-dbc0-46b1-adc2-6bfde25e625d');

INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('9bedde66-7892-4ad9-92ca-fa31191f6794', 'voice', 'Thank you for calling please hold.', 'neutral', 'https://i.imgur.com/YfJQV5z.png?id=284', 'completed', '28a179a5-e49c-4555-a893-f7dc6833f88c', '6faa556f-7f00-45cf-96e1-0d7e1ce7aa8c');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('cb5bd4ae-7218-47af-a24e-2c936c374ad0', 'voice', 'Can you provide more details about the issue', 'neutral', 'https://i.imgur.com/YfJQV5z.png?id=290', 'completed', '3b1b81f4-969d-45d8-aa3e-8f673bd0d69c', 'cff2876e-2b8d-4b8f-9afb-499218ffbb84');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('74fb0dae-595e-4c02-a40a-4739da93dcc0', 'chat', 'I need help with my order status.', 'positive', 'https://i.imgur.com/YfJQV5z.png?id=296', 'failed', 'fc4fa4ef-66c3-44bd-8e2c-668bbd863971', '22c59b85-34c0-4a02-867a-345767f8c4b4');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('00acb652-5a98-46cb-b5d1-bcb5bdecfc2b', 'voice', 'I need help with my order status.', 'positive', 'https://i.imgur.com/YfJQV5z.png?id=302', 'inprogress', 'aae38065-64c9-488f-9601-7d74b090de4e', 'c1f9c253-9585-416f-a7be-28937430caca');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('29208f22-2a5d-43e8-b8e9-d12cda0909ff', 'voice', 'Hello how can I assist you today', 'neutral', 'https://i.imgur.com/YfJQV5z.png?id=308', 'completed', 'fc4fa4ef-66c3-44bd-8e2c-668bbd863971', '1548d032-f227-4eb9-a9bd-0883e402964a');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('3e05a532-3922-4e34-aa1a-6b82462165ce', 'voice', 'Thank you for calling please hold.', 'neutral', 'https://i.imgur.com/YfJQV5z.png?id=314', 'completed', '3b1b81f4-969d-45d8-aa3e-8f673bd0d69c', 'a84f7f4e-4161-452a-b2a2-82d15e02a226');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('70e1cd87-3e51-49e7-aaf3-beb47d4f166d', 'voice', 'I need help with my order status.', 'neutral', 'https://i.imgur.com/YfJQV5z.png?id=320', 'completed', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '1548d032-f227-4eb9-a9bd-0883e402964a');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('f7277bdb-a7af-48d3-8de3-1bbb6d489bb7', 'voice', 'Thank you for calling please hold.', 'positive', 'https://i.imgur.com/YfJQV5z.png?id=326', 'inprogress', 'fc4fa4ef-66c3-44bd-8e2c-668bbd863971', '2c84abf4-3186-4dc9-8afe-32a7bb6adab0');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('d74c42a1-5ec1-4b61-8671-88bb7fce380f', 'chat', 'Thank you for calling please hold.', 'positive', 'https://i.imgur.com/YfJQV5z.png?id=332', 'failed', '683d5d6a-0622-4834-8cca-ad0849e68f83', 'fe14e62f-78e1-4142-b2f8-0a58e20a3e42');
INSERT INTO "Conversation" ("id", "type", "content", "sentiment", "recordingUrl", "status", "userId", "organizationId") VALUES ('6c29b031-dea1-4417-b466-2517062ff810', 'voice', 'Your request has been processed successfully.', 'neutral', 'https://i.imgur.com/YfJQV5z.png?id=338', 'failed', '7c071efd-55ae-4e52-9078-7b36e2ca2553', 'c1f9c253-9585-416f-a7be-28937430caca');

INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('62c2c043-cd2c-40d6-b1d7-ac08228768a2', 792, 'refund', 'reversed', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'fe14e62f-78e1-4142-b2f8-0a58e20a3e42');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('81a6b790-b8ac-474f-9ec3-4b8ef1b70150', 362, 'manualadjustment', 'pending', 'a8bc79c7-dbc0-46b1-adc2-6bfde25e625d', '53d08390-ea5e-4686-beb6-aa71e3bcc10d');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('c5738cd7-f8f3-439a-bcf4-372e7b7c7742', 543, 'bonus', 'pending', 'aae38065-64c9-488f-9601-7d74b090de4e', '22c59b85-34c0-4a02-867a-345767f8c4b4');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('b3d6102b-d69a-451b-bff2-14563454a9c8', 951, 'autorecharge', 'failed', '28a179a5-e49c-4555-a893-f7dc6833f88c', '6faa556f-7f00-45cf-96e1-0d7e1ce7aa8c');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('e304fcbd-de7b-4eae-9fe3-170775f139c7', 999, 'purchase', 'pending', '5e8be189-78c9-4f4a-b5cd-5a81d5134fa6', 'fe14e62f-78e1-4142-b2f8-0a58e20a3e42');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('011bd8d0-b455-48e0-bed7-4a8995a369af', 628, 'manualadjustment', 'inprogress', 'd0468694-8a7a-4af3-ae42-9f931d274e05', '53d08390-ea5e-4686-beb6-aa71e3bcc10d');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('4964510b-45b0-4e08-b45a-88700b12e23a', 326, 'manualadjustment', 'inprogress', 'aae38065-64c9-488f-9601-7d74b090de4e', '397d7006-f4d5-446d-aafe-9c00e287a866');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('2d4e743f-b038-4751-b889-ead01c7200de', 471, 'bonus', 'completed', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'cff2876e-2b8d-4b8f-9afb-499218ffbb84');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('e0f2b51c-0451-4c5d-8b24-b8fecd35168e', 798, 'manualadjustment', 'inprogress', '683d5d6a-0622-4834-8cca-ad0849e68f83', 'cff2876e-2b8d-4b8f-9afb-499218ffbb84');
INSERT INTO "CreditTransaction" ("id", "amount", "type", "status", "userId", "organizationId") VALUES ('3b0429e5-2c3f-44af-bfd2-8249b929a59d', 131, 'bonus', 'failed', 'd0468694-8a7a-4af3-ae42-9f931d274e05', '1548d032-f227-4eb9-a9bd-0883e402964a');

  `

  const sqls = splitSql(sql)

  for (const sql of sqls) {
    try {
      await prisma.$executeRawUnsafe(`${sql}`)
    } catch (error) {
      console.log(`Could not insert SQL: ${error.message}`)
    }
  }
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async error => {
    console.error(error)
    await prisma.$disconnect()
    process.exit(1)
  })
